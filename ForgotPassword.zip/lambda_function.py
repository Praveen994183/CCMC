import sys
import logging
import rds_config
import pymysql
import json

# RDS settings
rds_host = "tnau-dev.c5uedrzo7co7.ap-south-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    print(db_name)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    conn = None
    try:
        print(event)
        print(event['body'])
        
        conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=10)
        data = json.loads(event['body'])
        username = data['EMAIL']
        new_password = data['password']
        verify_password = data['verifypassword']
        old_password = 'Gis@123'
        
        # # Dummy old password for the sake of comparison
        # old_password = 'Gis@123'  
        
        if old_password == verify_password:
            sql = "UPDATE GIS_Data_Aggregator.USER SET PASSWORD=%s WHERE EMAIL=%s"
            print(sql)
            
            with conn.cursor() as cur:
                cur.execute(sql, (new_password, username))
                print("Executed Successfully")
                conn.commit()
                
                return {
                    "statusCode": 200,
                    "headers": {
                        "Content-Type": "application/json",
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                    },
                    "body": json.dumps({"status": "success"})
                }
        else:
            print('Enter Correct Old Password')
            return {
                "statusCode": 400,
                "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                "body": json.dumps({"status": "failure", "message": "Incorrect old password"})
            }
    except KeyError as e:
        logger.error("KeyError: Missing key %s", e)
        return {
            "statusCode": 400,
            "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            "body": json.dumps({"status": "failure", "message": f"Missing key: {str(e)}"})
        }
    except Exception as e:
        logger.error("ERROR: %s", e)
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            "body": json.dumps({"status": "failure", "message": "Internal server error"})
        }
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    test_event = {
        'body': json.dumps({
            'EMAIL': 'alwar.ksa@farmwiseai.com', 
            'password': 'alwar@2001',  
            'verifypassword': 'Gis@123'  
        })
    }
    result = lambda_handler(test_event, None)
    print("Test Result:", result)
