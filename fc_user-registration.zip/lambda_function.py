import sys
import logging
import rds_config
import pymysql
import json
from bson import json_util

# rds settings
rds_host = "tnau-dev.c5uedrzo7co7.ap-south-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    print(event)

    data = event['body']
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)

    # Check if user already exists
    sql_check_user_query = '''SELECT COUNT(*) FROM GIS_Data_Aggregator.USER WHERE EMAIL = %s'''
    with conn.cursor() as cur:
        cur.execute(sql_check_user_query, (data['mail_id'],))
        user_count = cur.fetchone()[0]

    if user_count > 0:
        return {
            "statusCode": 400,
            "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            "body": json.dumps({"message": "User already exists with this email"}, default=json_util.default)
        }

    # Construct SQL query with parameterized query to prevent SQL injection
    sql_insert_query = '''INSERT INTO GIS_Data_Aggregator.USER (NAME, EMAIL, MOBILE_NUMBER, ROLE, PASSWORD, Gender) 
                          VALUES (%s, %s, %s, %s, %s, %s)'''

    print(sql_insert_query)
    with conn.cursor() as cur:
        try:
            # Execute the query with parameters
            cur.execute(sql_insert_query, (data['user_name'], data['mail_id'], data['mobile_number'], 
                                            data['role_id'], data['password'], data['gender']))
            conn.commit()
            inserted_id = cur.lastrowid  # Get the ID of the last inserted row

            return {
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                "body": json.dumps({"message": "Inserted Successfully", "inserted_id": inserted_id}, default=json_util.default)}
            
        except pymysql.Error as e:
            print(e)
            return {
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                "body": json.dumps({"message": "Failed to insert", "error": str(e)}, default=json_util.default)}
if __name__ == '__main__':
    event = {
        "body": {
            "user_name": "Karkki",
            "mail_id": "karkki@farmwiseai.com",
            "mobile_number": "8110878957",
            "role_id": "GA",
            "password":"gis@123",
            "gender":"female"
        }
    }
    result = lambda_handler(event, None)
    print(result)