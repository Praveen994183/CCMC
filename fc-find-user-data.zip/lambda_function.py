import sys
import logging
import rds_config
import pymysql
import json
from bson import json_util
import hashlib
 
# rds settings
rds_host = "tnau-dev.c5uedrzo7co7.ap-south-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name
 
logger = logging.getLogger()
logger.setLevel(logging.INFO)
 
try:
    print(db_name)
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
 
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
 
 
def lambda_handler(event, context):
    print(event)
   # print(event['queryStringParameters'])
 
    data = json.loads(event["body"])
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
 
    with conn.cursor() as cur:
        try:
            args = (data['username'], data['passcode'])
            result_args = cur.callproc('SP_CHECK_LOGIN', args)
            row_headers = [x[0] for x in cur.description]
            rv = cur.fetchall()
            if not rv:
                return {
                    "statusCode": 404,
                    "headers": {
                        "Content-Type": "application/json",
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                    },
                    "body": json.dumps("User Not Found In Database", default=json_util.default)}
            else:
                json_data = []
                for result in rv:
                    json_data.append(dict(zip(row_headers, result)))
 
                print(json_data)
                return {
                    "statusCode": 200,
                    "headers": {
                        "Content-Type": "application/json",
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                    },
                    "body": json.dumps(json_data, default=json_util.default)}
 
        except pymysql.Error as e:
            print(e)
            return {
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                "body": json.dumps(json_data, default=json_util.default)}
 
 
if __name__ == '__main__':
    event = {
        "body": json.dumps ({
            "username": "naveen@farmwiseai.com",
            "passcode": "gis@123"
        })
    }
    lambda_handler(event, None)