#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "AllIsWell!"
db_name = "GIS_Data_Aggregator"